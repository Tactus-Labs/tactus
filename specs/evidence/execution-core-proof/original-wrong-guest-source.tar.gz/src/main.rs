#![no_main]
sp1_zkvm::entrypoint!(main);
fn main() {
    let genesis: tactus_o1_execution::Genesis = serde_json::from_slice(&sp1_zkvm::io::read_vec()).unwrap();
    let mut engine = tactus_o1_execution::Executor::new(&genesis).unwrap();
    let batch = sp1_zkvm::io::read_vec();
    engine.apply_batch(&batch).unwrap();
    sp1_zkvm::io::commit_slice(&genesis.allocation_bytes().unwrap());
    sp1_zkvm::io::commit_slice(&engine.anchor().encode());
    sp1_zkvm::io::commit_slice(engine.state_root().as_slice());
}
